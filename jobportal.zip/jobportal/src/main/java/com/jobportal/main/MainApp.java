package com.jobportal.main;

import com.jobportal.dao.UserDAO;
import com.jobportal.dao.JobDAO;
import com.jobportal.dao.CompanyDAO;
import com.jobportal.entity.User;
import com.jobportal.entity.Job;
import com.jobportal.entity.Company;

import java.util.List;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserDAO userDAO = new UserDAO();
        JobDAO jobDAO = new JobDAO();
        CompanyDAO companyDAO = new CompanyDAO();

        // ----------- Add User ----------- 
        System.out.println("Enter User Name: ");
        String name = scanner.nextLine();

        System.out.println("Enter User Email: ");
        String email = scanner.nextLine();

        System.out.println("Enter Password: ");
        String password = scanner.nextLine();

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);

        userDAO.saveUser(user);  // Save user to DB
        System.out.println("User added successfully from console!");

        // ----------- Add Company ----------- 
        System.out.println("\nEnter Company Name: ");
        String companyName = scanner.nextLine();

        System.out.println("Enter Company Location: ");
        String location = scanner.nextLine();

        Company company = new Company();
        company.setCompanyName(companyName);
        company.setLocation(location);

        companyDAO.saveCompany(company);  // Save company to DB
        System.out.println("Company added successfully from console!");

        // ----------- Add Job ----------- 
        System.out.println("\nEnter Job Title: ");
        String title = scanner.nextLine();

        System.out.println("Enter Job Description: ");
        String description = scanner.nextLine();

        Job job = new Job();
        job.setTitle(title);
        job.setDescription(description);
        job.setCompany(company);  // Link company to job

        jobDAO.saveJob(job);  // Save job to DB
        System.out.println("Job added successfully from console!");

        // ----------- Get All Users ----------- 
        List<User> users = userDAO.getAllUsers();
        System.out.println("\nUsers List:");
        for (User u : users) {
            System.out.println("Name: " + u.getName() + ", Email: " + u.getEmail() + ", Password: " + u.getPassword());
        }

        // ----------- Get All Companies ----------- 
        List<Company> companies = companyDAO.getAllCompanies();
        System.out.println("\nCompanies List:");
        for (Company c : companies) {
            System.out.println("ID: " + c.getId() + ", Name: " + c.getCompanyName() + ", Location: " + c.getLocation());
        }

        // ----------- Get All Jobs ----------- 
        List<Job> jobs = jobDAO.getAllJobs();
        System.out.println("\nJobs List:");
        for (Job j : jobs) {
            System.out.println("Job ID: " + j.getJob_id() + ", Title: " + j.getTitle() + ", Description: " + j.getDescription() + ", Salary: " + j.getSalary() + ", Company: " + j.getCompany().getCompanyName());
        }

        scanner.close();
    }
}