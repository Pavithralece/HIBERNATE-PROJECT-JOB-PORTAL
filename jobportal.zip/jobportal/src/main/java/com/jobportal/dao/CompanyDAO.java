package com.jobportal.dao;

import com.jobportal.entity.Company;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class CompanyDAO {
    private SessionFactory sessionFactory;

    public CompanyDAO() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(Company.class)
                .buildSessionFactory();
    }

    // Method to save a company
    public void saveCompany(Company company) {
        Session session = sessionFactory.openSession();  // Use openSession() instead of getCurrentSession()
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();  // Begin the transaction
            session.save(company);  // Save the company to the database
            transaction.commit();  // Commit the transaction
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();  // Rollback if there's an exception
            }
            e.printStackTrace();
        } finally {
            session.close();  // Always close the session
        }
    }

    // Method to fetch all companies
    public List<Company> getAllCompanies() {
        Session session = sessionFactory.openSession();  // Use openSession() here as well
        Transaction transaction = null;
        List<Company> companies = null;
        try {
            transaction = session.beginTransaction();  // Begin the transaction
            companies = session.createQuery("from Company", Company.class).getResultList();  // Get all companies from the database
            transaction.commit();  // Commit the transaction
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();  // Rollback if there's an exception
            }
            e.printStackTrace();
        } finally {
            session.close();  // Always close the session
        }
        return companies;
    }
}