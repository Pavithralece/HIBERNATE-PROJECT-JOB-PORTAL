package com.jobportal.dao;

import com.jobportal.entity.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class UserDAO {
    private SessionFactory sessionFactory;

    public UserDAO() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml")
                .addAnnotatedClass(User.class)
                .buildSessionFactory();
    }

    // Method to save a user
    public void saveUser(User user) {
        Session session = sessionFactory.openSession();  // Use openSession() instead of getCurrentSession()
        Transaction transaction = null;
        try {
            transaction = session.beginTransaction();  // Begin the transaction
            session.save(user);  // Save the user to the database
            transaction.commit();  // Commit the transaction
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();  // Rollback if there's an exception
            }
            e.printStackTrace();
        } finally {
            session.close();  // Always close the session
        }
    }

    // Method to fetch all users
    public List<User> getAllUsers() {
        Session session = sessionFactory.openSession();  // Use openSession() here as well
        Transaction transaction = null;
        List<User> users = null;
        try {
            transaction = session.beginTransaction();  // Begin the transaction
            users = session.createQuery("from User", User.class).getResultList();  // Get all users from the database
            transaction.commit();  // Commit the transaction
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();  // Rollback if there's an exception
            }
            e.printStackTrace();
        } finally {
            session.close();  // Always close the session
        }
        return users;
    }
}