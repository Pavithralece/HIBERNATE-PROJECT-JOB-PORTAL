package com.jobportal.dao;

import com.jobportal.entity.Application;
import com.jobportal.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class ApplicationDAO {

    public void saveApplication(Application application) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(application);
            transaction.commit();
            System.out.println("Application saved successfully!");


        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }
}
