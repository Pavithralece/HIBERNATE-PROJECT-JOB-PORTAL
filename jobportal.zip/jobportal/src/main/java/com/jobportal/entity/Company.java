package com.jobportal.entity;

import javax.persistence.*;

@Entity
@Table(name = "company")
public class Company {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String companyName;
    private String location;

    // **Default Constructor (Needed for JPA)**
    public Company() {
    }

    // **Parameterized Constructor**
    public Company(int id, String companyName, String location) {
        this.id = id;
        this.companyName = companyName;
        this.location = location;
    }

    // **Getters**
    public int getId() {
        return id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getLocation() {
        return location;
    }

    // **Setters (Missing in your code)**
    public void setId(int id) {
        this.id = id;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}